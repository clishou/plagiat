
import { createBrowserRouter } from 'react-router-dom'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import DocumentNew from './pages/DocumentNew'
import DocumentShow from './pages/DocumentShow'
import AdminPricing from './pages/AdminPricing'
import Payments from './pages/Payments'
import DocumentBatch from './pages/DocumentBatch'

export const router = createBrowserRouter([
  { path: '/', element: <Dashboard/> },
  { path: '/login', element: <Login/> },
  { path: '/register', element: <Register/> },
  { path: '/documents/new', element: <DocumentNew/> },
  { path: '/documents/batch', element: <DocumentBatch/> },
  { path: '/documents/:id', element: <DocumentShow/> },
  { path: '/payments', element: <Payments/> },
  { path: '/admin/pricing', element: <AdminPricing/> },
])
