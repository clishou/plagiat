
export type Role = 'ADMIN' | 'USER'
export type DocCategory = 'These' | 'Memoire' | 'Article' | 'Ouvrage' | 'Autre'
export type DocStatus = 'PENDING_PAYMENT' | 'PAID' | 'ANALYZING' | 'DONE' | 'FAILED' | 'UPLOADED'

export interface User { id: number; email: string; full_name?: string; role: Role }
export interface DocumentOut {
  id: number; title: string; author: string; category: DocCategory; word_count: number; price_cfa: number; status: DocStatus;
}
