
import { useQuery } from '@tanstack/react-query'
import { api } from './api'
export function useMe(){
  return useQuery({
    queryKey: ['me'],
    queryFn: async ()=> (await api.get('/auth/me')).data,
    staleTime: 5*60*1000,
  })
}
