
import { api, setToken } from './api'
export async function login(email: string, password: string) {
  const { data } = await api.post('/auth/login', { email, password })
  setToken(data.access_token); return data
}
export async function register(email: string, password: string, full_name?: string) {
  const { data } = await api.post('/auth/register', { email, password, full_name })
  return data
}
export function logout(){ setToken(null) }
