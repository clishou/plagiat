
export function subscribeDocumentStatus(id: number, onData:(d:any)=>void){
  const es = new EventSource(`${import.meta.env.VITE_API_BASE}/events/documents/${id}`)
  es.onmessage = (e)=>{ try{ onData(JSON.parse(e.data)); }catch{} }
  es.onerror = ()=> es.close()
  return ()=> es.close()
}
