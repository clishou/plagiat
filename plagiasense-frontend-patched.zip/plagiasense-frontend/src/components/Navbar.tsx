
import { Link, useLocation } from 'react-router-dom'

export default function Navbar(){
  const loc = useLocation()
  const Tab = ({to,label}:{to:string;label:string})=>(
    <Link to={to} className={`px-3 py-1.5 rounded ${loc.pathname===to?'bg-ucad text-white':'hover:bg-gray-100'}`}>{label}</Link>
  )
  return (
    <div className="border-b bg-white">
      <div className="mx-auto max-w-5xl px-4 h-14 flex items-center justify-between">
        <Link to="/" className="font-bold text-ucad">PlagiaSense</Link>
        <div className="flex items-center gap-2 text-sm">
          <Tab to="/" label="Dashboard"/>
          <Tab to="/documents/new" label="Nouveau"/>
          <Tab to="/payments" label="Paiements"/>
          <Tab to="/admin/pricing" label="Admin"/>
        </div>
      </div>
    </div>
  )
}
