
import { useRef, useState } from 'react'

export default function FileDropzone({ onFile }: { onFile: (f: File)=>void }){
  const ref = useRef<HTMLInputElement>(null)
  const [hover,setHover]=useState(false)
  return (
    <div onClick={()=>ref.current?.click()} onDragOver={e=>{e.preventDefault(); setHover(true);}} onDragLeave={()=>setHover(false)} onDrop={e=>{e.preventDefault(); setHover(false); const f=e.dataTransfer.files?.[0]; if(f) onFile(f);}}
      className={`border-2 border-dashed rounded p-10 text-center cursor-pointer ${hover?'bg-gray-50':''}`}>
      Déposez votre fichier ou cliquez pour sélectionner
      <input ref={ref} type="file" className="hidden" onChange={e=>{ const f=e.target.files?.[0]; if(f) onFile(f); }} />
    </div>
  )
}
