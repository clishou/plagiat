
import { ReactNode } from 'react'
import { useMe } from '../lib/me'
export default function Protected({ roles, children }:{ roles?: ('ADMIN'|'USER')[], children: ReactNode }){
  const { data:me, isLoading } = useMe()
  if(isLoading) return <div className="p-6">Chargement…</div>
  if(!me) return <div className="p-6">Veuillez vous connecter.</div>
  if(roles && !roles.includes(me.role)) return <div className="p-6">Accès refusé.</div>
  return <>{children}</>
}
