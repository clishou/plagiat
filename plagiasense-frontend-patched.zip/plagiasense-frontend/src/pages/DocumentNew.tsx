
import { useState } from 'react'
import Navbar from '../components/Navbar'
import FileDropzone from '../components/FileDropzone'
import { api } from '../lib/api'
import { DocCategory } from '../lib/types'
import { toast } from 'sonner'

export default function DocumentNew(){
  const [title,setTitle]=useState('')
  const [author,setAuthor]=useState('')
  const [category,setCategory]=useState<DocCategory>('Article')
  const [file,setFile]=useState<File|null>(null)
  const [loading,setLoading]=useState(false)

  async function submit(){
    if(!file) return toast.error('Sélectionnez un fichier')
    setLoading(true)
    try{
      const fd = new FormData()
      fd.append('title', title)
      fd.append('author', author)
      fd.append('category', category)
      fd.append('file', file)
      const { data } = await api.post('/documents', fd, { headers: { 'Content-Type': 'multipart/form-data' }})
      const { data: pay } = await api.post(`/payments/${data.id}/init`)
      window.location.href = pay.payment_url
    } finally { setLoading(false) }
  }

  return (
    <div>
      <Navbar/>
      <div className="max-w-3xl mx-auto p-4 space-y-4">
        <h1 className="text-xl font-semibold">Nouveau document</h1>
        <label className="block text-sm">Titre<input className="w-full border rounded p-2" placeholder="Titre" value={title} onChange={e=>setTitle(e.target.value)} /></label>
        <label className="block text-sm">Auteur<input className="w-full border rounded p-2" placeholder="Auteur" value={author} onChange={e=>setAuthor(e.target.value)} /></label>
        <label className="block text-sm">Catégorie<select className="w-full border rounded p-2" value={category} onChange={e=>setCategory(e.target.value as DocCategory)}>
          {(['These','Memoire','Article','Ouvrage','Autre'] as DocCategory[]).map(c=> <option key={c} value={c}>{c}</option>)}
        </select></label>
        <FileDropzone onFile={setFile} />
        <button disabled={loading} onClick={submit} className="px-4 py-2 bg-ucad text-white rounded disabled:opacity-60">{loading? 'Traitement…':'Procéder au paiement'}</button>
      </div>
    </div>
  )
}
