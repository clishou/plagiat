
import { useEffect, useState } from 'react'
import Navbar from '../components/Navbar'
import { api } from '../lib/api'

export default function Payments(){
  const [rows,setRows]=useState<any[]>([])
  useEffect(()=>{ api.get('/payments').then(r=> setRows(r.data.items||r.data)); },[])
  return (
    <div>
      <Navbar/>
      <div className="max-w-5xl mx-auto p-4">
        <h1 className="text-xl font-semibold mb-3">Historique des paiements</h1>
        <div className="overflow-x-auto border rounded">
          <table className="min-w-full text-sm">
            <thead className="bg-ucad/5">
              <tr>
                <th className="text-left p-2 font-semibold">ID</th>
                <th className="text-left p-2 font-semibold">Doc</th>
                <th className="text-left p-2 font-semibold">Montant</th>
                <th className="text-left p-2 font-semibold">Statut</th>
                <th className="text-left p-2 font-semibold">Date</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r,i)=>(
                <tr key={i} className="border-t">
                  <td className="p-2">{r.id}</td>
                  <td className="p-2">{r.document_id}</td>
                  <td className="p-2">{Number(r.amount_cfa).toFixed(2)} F</td>
                  <td className="p-2">{r.status}</td>
                  <td className="p-2">{r.created_at}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
