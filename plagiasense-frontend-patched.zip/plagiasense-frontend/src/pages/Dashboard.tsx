
import { useEffect, useState } from 'react'
import Navbar from '../components/Navbar'
import { api } from '../lib/api'
import { DocumentOut } from '../lib/types'
import { Link } from 'react-router-dom'

export default function Dashboard(){
  const [docs,setDocs]=useState<DocumentOut[]>([])
  useEffect(()=>{ api.get('/documents').then(r=>setDocs(r.data.items || r.data)); },[])
  return (
    <div>
      <Navbar/>
      <div className="max-w-5xl mx-auto p-4">
        <h1 className="text-xl font-semibold mb-4">Mes documents</h1>
        <div className="grid gap-3">
          {docs.map(d=> (
            <Link key={d.id} to={`/documents/${d.id}`} className="p-3 border rounded hover:bg-gray-50">
              <div className="font-medium">{d.title} <span className="text-xs text-gray-500">({d.category})</span></div>
              <div className="text-sm text-gray-600">{d.word_count} mots · {Number(d.price_cfa).toFixed(2)} F CFA · statut: {d.status}</div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
