
import { useEffect, useState } from 'react'
import Navbar from '../components/Navbar'
import { api } from '../lib/api'

export default function AdminPricing(){
  const [price,setPrice]=useState<number>(0.5)
  useEffect(()=>{ api.get('/admin/pricing').then(r=> setPrice(r.data.price_per_word_cfa)); },[])
  async function save(){ await api.put('/admin/pricing', null, { params: { value: price }}); }
  return (
    <div>
      <Navbar/>
      <div className="max-w-3xl mx-auto p-4 space-y-4">
        <h1 className="text-xl font-semibold">Tarification</h1>
        <div className="flex items-center gap-3">
          <input type="number" step="0.01" className="border rounded p-2" value={price} onChange={e=>setPrice(parseFloat(e.target.value))} />
          <button onClick={save} className="px-4 py-2 bg-ucad text-white rounded">Enregistrer</button>
        </div>
      </div>
    </div>
  )
}
