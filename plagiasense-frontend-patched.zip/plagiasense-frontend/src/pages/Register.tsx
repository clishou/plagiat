
import { useState } from 'react'
import { register } from '../lib/auth'
import { useNavigate } from 'react-router-dom'
import { toast } from 'sonner'

export default function Register(){
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const [full_name,setFull]=useState('')
  const nav = useNavigate()
  return (
    <div className="max-w-md mx-auto p-6">
      <h1 className="text-2xl font-semibold mb-4">Inscription</h1>
      <form onSubmit={async e=>{e.preventDefault(); try{ await register(email,password,full_name); toast.success('Compte créé'); nav('/login'); } catch{} }} className="space-y-3">
        <label className="block text-sm">Nom complet<input className="w-full border rounded p-2" placeholder="Nom complet" value={full_name} onChange={e=>setFull(e.target.value)} /></label>
        <label className="block text-sm">Email<input className="w-full border rounded p-2" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /></label>
        <label className="block text-sm">Mot de passe<input className="w-full border rounded p-2" type="password" placeholder="Mot de passe" value={password} onChange={e=>setPassword(e.target.value)} /></label>
        <button className="w-full bg-ucad text-white rounded p-2">Créer le compte</button>
      </form>
    </div>
  )
}
