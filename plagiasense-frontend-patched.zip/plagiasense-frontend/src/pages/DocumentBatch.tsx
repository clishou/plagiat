
import { useState } from 'react'
import Navbar from '../components/Navbar'
import { api } from '../lib/api'

export default function DocumentBatch(){
  const [files,setFiles]=useState<FileList|null>(null)
  const [resp,setResp]=useState<any[]>([])
  async function submit(){
    if(!files) return; const fd=new FormData();
    Array.from(files).forEach(f=> fd.append('file[]', f));
    const { data } = await api.post('/documents/batch', fd);
    setResp(data.items||data);
  }
  return (
    <div>
      <Navbar/>
      <div className="max-w-4xl mx-auto p-4 space-y-3">
        <h1 className="text-xl font-semibold">Multi-upload</h1>
        <input type="file" multiple onChange={e=>setFiles(e.target.files)} />
        <button onClick={submit} className="px-4 py-2 bg-ucad text-white rounded">Calculer & Payer</button>
        {!!resp.length && <pre className="bg-gray-50 p-3 rounded overflow-auto">{JSON.stringify(resp,null,2)}</pre>}
      </div>
    </div>
  )
}
