
import { useState } from 'react'
import { login } from '../lib/auth'
import { useNavigate, Link } from 'react-router-dom'
import { toast } from 'sonner'

export default function Login(){
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const nav = useNavigate()
  return (
    <div className="max-w-md mx-auto p-6">
      <h1 className="text-2xl font-semibold mb-4">Connexion</h1>
      <form onSubmit={async e=>{e.preventDefault(); try{ await login(email,password); toast.success('Connecté'); nav('/'); } catch{ }}} className="space-y-3">
        <label className="block text-sm">Email<input className="w-full border rounded p-2" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /></label>
        <label className="block text-sm">Mot de passe<input className="w-full border rounded p-2" type="password" placeholder="Mot de passe" value={password} onChange={e=>setPassword(e.target.value)} /></label>
        <button className="w-full bg-ucad text-white rounded p-2">Se connecter</button>
      </form>
      <div className="mt-3 text-sm">Pas de compte ? <Link to="/register" className="underline">S'inscrire</Link></div>
    </div>
  )
}
