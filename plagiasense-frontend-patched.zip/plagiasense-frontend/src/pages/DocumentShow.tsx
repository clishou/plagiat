
import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import Navbar from '../components/Navbar'
import { api } from '../lib/api'
import { DocumentOut } from '../lib/types'
import { subscribeDocumentStatus } from '../lib/sse'

export default function DocumentShow(){
  const { id } = useParams()
  const [doc,setDoc]=useState<(DocumentOut & {report_url?:string, certificate_url?:string})|null>(null)

  useEffect(()=>{
    api.get(`/documents/${id}`).then(r=> setDoc(r.data))
  },[id])

  useEffect(()=>{
    if(!id) return
    const off = subscribeDocumentStatus(Number(id), (d)=>{
      setDoc(prev=> prev? ({...prev, status: d.status}) : prev)
    })
    return off
  },[id])

  return (
    <div>
      <Navbar/>
      <div className="max-w-3xl mx-auto p-4 space-y-3">
        <h1 className="text-xl font-semibold">{doc?.title}</h1>
        <div className="text-sm text-gray-600">Statut: <span className="font-medium">{doc?.status}</span></div>
        <div className="flex gap-3">
          {doc?.report_url && <a className="px-3 py-2 rounded border" href={doc.report_url} target="_blank">Télécharger Rapport</a>}
          {doc?.certificate_url && <a className="px-3 py-2 rounded border" href={doc.certificate_url} target="_blank">Télécharger Certificat</a>}
        </div>
      </div>
    </div>
  )
}
