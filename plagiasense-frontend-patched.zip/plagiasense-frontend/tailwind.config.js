
/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ucad: {
          DEFAULT: '#002147'
        }
      }
    }
  },
  plugins: [],
}
